package Uni;

import java.util.Scanner;

public class N_numeros {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		int n = 0, b = 0, c = 0, suma = 0, a = 0;
		
		System.out.println("Ingrese la cantidad de numeros:");
		c = tc.nextInt();
		
		do {
			System.out.println("Ingrese un numero");
			n = tc.nextInt();
			if (n > 0) {
				suma = suma + n;
			}else if(n <= 0) {
				b = b + 1;
			}
				a = a + 1;
		}while (a <= c);
		System.out.println("El resultado de la suma es: " +suma);
		System.out.println("La cantidad de numeros negativos es: " +b);
	}
}